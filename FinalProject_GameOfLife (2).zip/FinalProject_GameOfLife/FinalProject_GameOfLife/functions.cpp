#include "header.h"

using namespace std;

const int NEW_CAR = 15000, USED_CAR = 8000, BUS_PASS = 250, BIKE = 125, CAR_INSURANCE = 300,
FORMAL_CLOTHING = 150, SEMI_FORMAL_CLOTHING = 80, NON_FORMAL_CLOTHING = 45,
GYM = 20, DELUXE_HYGENE = 45, AVERAGE_HYGENE = 25;

void transportation(double userTotal)
{
	//insurance
	int userInput = 0;
	string insuranceAnswer = "";
	cout << "Transportation" << endl
		<< "**************" << endl << endl
		<< "Please choose one of the following transportation options:" << endl << endl
		<< "1.) Buy a new car ($)" << endl
		<< "2.) Buy a used car ($)" << endl
		<< "3.) Get a bus pass ($)" << endl
		<< "4.) Buy a bike ($)" << endl << endl
		<< "Your selection: ";
	cin >> userInput;

	switch (userInput)
	{
	case 1: userTotal = userTotal - NEW_CAR;
		cout << "Would you like insurance with your new car for $300? (yes or no)";
		getline(cin, insuranceAnswer);
		if (insuranceAnswer == "YES" || insuranceAnswer == "Yes" || insuranceAnswer == "yes")
			userTotal = userTotal - CAR_INSURANCE;
		break;
	case 2: userTotal = userTotal - USED_CAR;
		cout << "Would you like insurance with your used car for $300? (yes or no)";
		getline(cin, insuranceAnswer);
		if (insuranceAnswer == "YES" || insuranceAnswer == "Yes" || insuranceAnswer == "yes")
			userTotal = userTotal - CAR_INSURANCE;
		break;
	case 3: userTotal = userTotal - BUS_PASS;
		break;
	case 4: userTotal = userTotal - BIKE;
		break;
	default: cout << "Invalid entry, please try again" << endl;
		transportation(userTotal);
	}
}

void clothes(double userTotal)
{
	int userChoice = 0;
	cout << "Clothing" << endl
		<< "*********" << endl << endl
		<< "Please select one of the following: " << endl << endl
		<< "1.) Formal - includes suit and tie and dress clothes ($150)" << endl
		<< "2.) Semi-Formal - includes polos, khakis, and casual dresses ($80)" << endl
		<< "3.) Non-Formal - includes t-shirts and jeans ($45)" << endl << endl
		<< "Your selection: ";
	cin >> userChoice;

	//do a seperate thing for descriptions if they would like to see them (if statement?)

	if (userChoice == 1)
		userTotal = userTotal - FORMAL_CLOTHING;
	else if (userChoice == 2)
		userTotal = userTotal - SEMI_FORMAL_CLOTHING;
	else if (userChoice == 3)
		userTotal = userTotal - NON_FORMAL_CLOTHING;
	else
	{
		cout << "Invalid entry, please try again";
		clothes(userTotal);
	}
}

void personalHealth(double userTotal)
{
	string gymAnswer;
	int hygeneSelection = 0;
	cout << "Personal Health" << endl
		<< "****************" << endl << endl
		<< "Would you like a gym membership ($20)? (yes or no): ";
	getline(cin, gymAnswer);
	cin.ignore();
	if (gymAnswer == "YES" || gymAnswer == "Yes" || gymAnswer == "yes")
	{
		userTotal = userTotal - GYM;
	}

	cout << endl << endl << "Please select one of the following:" << endl << endl
		<< "1.) Deluxe personal hygene - includes quality lotions, washes, shampoos ($45)" << endl
		<< "2.) Average personal hygene - includes basic washes and shampoos ($25)" << endl << endl
		<< "Your selection: ";
	cin >> hygeneSelection;

	if (hygeneSelection == 1)
	{
		userTotal = userTotal - DELUXE_HYGENE;
	}
	else if (hygeneSelection == 2)
	{
		userTotal = userTotal - AVERAGE_HYGENE;
	}
}