#pragma once
#include <iostream>
#include <string>

using namespace std;

void transportation(double userTotal);
void clothes(double userTotal);
void personalHealth(double userTotal);